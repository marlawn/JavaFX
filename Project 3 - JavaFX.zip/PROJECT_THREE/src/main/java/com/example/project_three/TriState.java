package com.example.project_three;
/**
 * International object class that extends NonResident and is used throughout the project.
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class TriState extends NonResident {
    /** String to represent the state */
    private String state;

    /**
     * Constructor for a Tri-state student with no parameters.
     */
    public TriState() {
        super();
        this.state = null;
    }

    /**
     * Constructor for a Tri-state student with all parameters.
     * @param prf profile as a Profile object.
     * @param mjr major as a Major datatype.
     * @param crd credits as an integer.
     * @param st state as a String.
     */
    public TriState(Profile prf, Major mjr, int crd, String st) {
        super(prf, mjr, crd);
        this.state = st;
    }

    /**
     * Overrides the toString() method.
     * @return "(non-resident)(tri-state: [STATE])"
     */
    @Override
    public String toString() {
        return "(non-resident)(tri-state:" + state + ")";
    }

    /**
     * Checks to see if creditsEnrolled is valid.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return true if credits are valid, false otherwise.
     */
    @Override
    public boolean isValid(int creditsEnrolled) {
        if (creditsEnrolled < Constants.MIN_CRED || creditsEnrolled > Constants.MAX_CRED) {
            return false;
        }
        return true;
    }

    /**
     * Returns tuition as a double.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return how much tuition is due as a double.
     */
    @Override
    public double tuitionDue(int creditsEnrolled) {
        if (creditsEnrolled < Constants.INT_CRED) {
            return Constants.PART_NONRES_RATE * creditsEnrolled + Constants.PART_UNI_FEE;
        } else if (creditsEnrolled <= Constants.STEEN || state.toUpperCase().equals("NY")) {
            return Constants.FULL_NONRES_INT_TUITION - Constants.NY_DISC;
        } else if (creditsEnrolled <= Constants.STEEN || state.toUpperCase().equals("CT")) {
            return Constants.FULL_NONRES_INT_TUITION - Constants.CT_DISC;
        }
        return Constants.NOT_FOUND;
    }
}
