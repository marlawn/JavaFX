package com.example.project_three;
/**
 * International object class that extends NonResident and is used throughout the project.
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class International extends NonResident {
    /** boolean to represent if International student is studying abroad or not */
    private boolean isStudyAbroad;

    /**
     * Constructor for an International student with no parameters.
     */
    public International() {
        super();
        this.isStudyAbroad = false;
    }

    /**
     * Constructor for an international student with all the parameters.
     * @param prf profile as a Profile object.
     * @param mjr major as a Major datatype.
     * @param crd credits as an integer.
     * @param stdabrd studying abroad boolean.
     */
    public International(Profile prf, Major mjr, int crd, boolean stdabrd) {
        super(prf,mjr,crd);
        this.isStudyAbroad = stdabrd;
    }

    /**
     * Overrides the toString() method.
     * @return "(non-resident)(international:study abroad)" if studying abroad, "(non-resident)(international) otherwise"
     */
    @Override
    public String toString() {
        if (isStudyAbroad) {
            return "(non-resident)(international:study abroad)";
        }
        return "(non-resident)(international)";
    }

    /**
     * Checks to see if creditsEnrolled is valid.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return true if credits are valid, false otherwise.
     */
    @Override
    public boolean isValid(int creditsEnrolled) {
        if (!isStudyAbroad) {
            if (creditsEnrolled < Constants.INT_CRED || creditsEnrolled > Constants.MAX_CRED) return false;
        } else {
            if (isStudyAbroad && creditsEnrolled < Constants.MIN_CRED || creditsEnrolled > Constants.INT_CRED) return false;
        }
        return true;
    }

    /**
     * Returns tuition due as a double.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return how much tuition is due as a double.
     */
    @Override
    public double tuitionDue(int creditsEnrolled) {
        if (creditsEnrolled < 12) {
            return Constants.PART_NONRES_RATE * creditsEnrolled + Constants.PART_UNI_FEE;
        } else if (creditsEnrolled <= 16 && !isStudyAbroad) {
            return Constants.FULL_NONRES_INT_TUITION + Constants.UNIVERSITY_FEE + Constants.HEALTH_INSURANCE;
        } else if (creditsEnrolled <= 16 && isStudyAbroad) {
            return Constants.UNIVERSITY_FEE + Constants.HEALTH_INSURANCE;
        }
        return Constants.NOT_FOUND;
    }
}
