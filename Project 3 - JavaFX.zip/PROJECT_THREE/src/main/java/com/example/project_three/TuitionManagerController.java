/**
 * Controller for the stage and scene that is launched in TuitionManagerMain.java
 * @author Marlon Vergara
 * @author Luis Castellanos
 */

package com.example.project_three;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class TuitionManagerController {
    /** first name */
    private String fn;

    /** last name */
    private String ln;

    /** date of birth */
    private Date dob;

    /** major */
    private Major mjr;

    /** new Roster object */
    Roster r = new Roster();

    /** new Enrollment object */
    Enrollment e = new Enrollment();

    /** output area for adding a student */
    @FXML
    private Label studentResult;
    /** output area for loading a student list file */
    @FXML
    private Label loadResult;
    /** output area for printing */
    @FXML
    private Label printResult;
    /** output area for removing a student */
    @FXML
    private Label removeResult;
    /** output area for changing major */
    @FXML
    private Label changeResult;
    /** output area for enrolling a student */
    @FXML
    private Label enrollResult;
    /** output area for deleting a result */
    @FXML
    private Label deleteResult;
    /** output aread for awarding a scholarship */
    @FXML
    private Label scholarhipResult;
    /** output area for ending the semester */
    @FXML
    private Label endSemesterResult;
    // BUTTONS
    /** button used in the print tab for sorting by name */
    @FXML
    private Button PButton;
    /** button used in the print tab for sorting by standing */
    @FXML
    private Button PSButton;
    /** button used in the print tab for sorting by school, major */
    @FXML
    private Button PCButton;
    /** button used in the print tab for enrollment */
    @FXML
    private Button PEButton;
    /** button used in the print tab for displaying tuition dude */
    @FXML
    private Button PTButton;
    /** button used in the load students tab */
    @FXML
    private Button LSButton;
    /** button used in the Add Students tab */
    @FXML
    private Button enterButton;
    /** button used in the Remove Students tab */
    @FXML
    private Button RButton;
    /** button used in the Change Major tab */
    @FXML
    private Button CButton;
    /** button used in the Enroll Student tab */
    @FXML
    private Button EButton;
    /** button used in the Delete from Enrollment tab */
    @FXML
    private Button DButton;
    /** button used in the Award Scholarship tab */
    @FXML
    private Button SButton;
    /** button used in the End Semester tab */
    @FXML
    private Button SEButton;
    // CHOICE BOXES
    /** choice box used in Add Students to choose type of student */
    @FXML
    private ChoiceBox stdBox;
    // TExT FIELDS
    /** text field for true/false option on study abroad choice */
    @FXML
    private TextField bool;
    /** text field used in the state option for Tri-State option */
    @FXML
    private TextField state;
    /** text field used in the credits option */
    @FXML
    private TextField creds;
    /** text field used to enter the first name */
    @FXML
    private TextField firstName;
    /** text field used to enter the last name */
    @FXML
    private TextField lastName;
    /** text field used to enter the date */
    @FXML
    private TextField date;
    /** text field used to enter the first name in the remove method */
    @FXML
    private TextField RFirstName;
    /** text field used to enter the last name in the remove method */
    @FXML
    private TextField RLastName;
    /** text field used to enter the date in the remove method*/
    @FXML
    private TextField RDate;
    /** text field used to enter the first name in the change major method */
    @FXML
    private TextField CFirstName;
    /** text field used to enter the last name in the change major method */
    @FXML
    private TextField CLastName;
    /** text field used to enter the date in the change major method */
    @FXML
    private TextField CDate;
    /** text field used to enter the major in the change major method */
    @FXML
    private TextField CMajor;
    /** text field used to enter the first name in the enroll student method */
    @FXML
    private TextField EFirstName;
    /** text field used to enter the last name in the enroll student method */
    @FXML
    private TextField ELastName;
    /** text field used to enter the credits enrolled in the enroll student method */
    @FXML
    private TextField ECreds;
    /** text field used to enter the date in the enroll student method */
    @FXML
    private TextField EDate;
    /** text field used to enter the first name in the delete enrollment method */
    @FXML
    private TextField DFirstName;
    /** text field used to enter the last name in the delete enrollment method */
    @FXML
    private TextField DLastName;
    /** text field used to enter the date in the delete enrollment method */
    @FXML
    private TextField DDate;
    /** text field used to enter the major in the delete enrollment method */
    @FXML
    private TextField major;
    /** text field used to enter the major */
    @FXML
    private TextField loadStudents;
    /** text field used to enter the first name in the Award Scholarship method */
    @FXML
    private TextField SFirstName;
    /** text field used to enter the last name in the Award Scholarship method */
    @FXML
    private TextField SLastName;
    /** text field used to enter the date in the Award Scholarship method */
    @FXML
    private TextField SDate;
    /** text field used to enter the scholarship amount in the Award Scholarship method */
    @FXML
    private TextField SScholarship;

    /** Drop-down options for student type */
    ObservableList<String> stdList = FXCollections.observableArrayList("Resident", "Non-Resident", "Tri-State", "International");

    /**
     * Adds student to roster with the following restrictions:
     * <ul>
     *     <li>Any date of birth that is not a valid calendar date</li>
     *     <li>The date of birth is today or a future date</li>
     *     <li>A student who is less than 16 years old</li>
     *     <li>The major doesn’t exist</li>
     *     <li>The student is in the roster already</li>
     *     <li>Negative number of credit completed</li>
     * </ul>
     * @param fname first name to add to profile.
     * @param lname last name to add to profile.
     * @param date date of birth to add to profile.
     * @param major major to add to student object.
     * @param creditsCompleted credits completed to add to student object.
     */
    private void A(String command, String fname, String lname, String date,
                   String major, String creditsCompletedString, String extra) {
        int creditsCompleted;
        try {
            creditsCompleted = Integer.parseInt(creditsCompletedString);
        } catch (NumberFormatException e) {
            studentResult.setText("Credits completed invalid: not an integer");
            return;
        }

        fn = fname.substring(0,1).toUpperCase() + fname.substring(1).toLowerCase(); // correct casing
        ln = lname.substring(0,1).toUpperCase() + lname.substring(1).toLowerCase(); // correct casing
        dob = new Date(date);
        if (validity(dob, creditsCompleted, major) == false) return;
        mjr = Major.valueOf(major.toUpperCase()); // Makes the major input not case sensitive (i.e. "ee" -> "EE")
        Profile prf = new Profile(fn, ln, dob);

        if (command.equals("AR")) AR(fn, ln, date, major, creditsCompleted);
        else if (command.equals("AN")) AN(fn, ln, date, major, creditsCompleted);
        else if (command.equals("AT")) {
            AT(fn, ln, date, major, creditsCompleted, extra);
        }
        else if (command.equals("AI") && extra == null) AI(fn, ln, date, major, creditsCompleted, false);
        else AI(fn, ln, date, major, creditsCompleted, Boolean.parseBoolean(extra));
    }



    /**
     * Adds resident.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     */
    private void AR(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        Resident res = new Resident(prf, mjr, crd);

        boolean bool = r.add(res);
        if (bool) studentResult.setText(fname + " " + lname + " " + date + " added to the roster.");
        else studentResult.setText(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds non-resident student.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     */
    private void AN(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        NonResident nonres = new NonResident(prf, mjr, crd);

        boolean bool = r.add(nonres);
        if (bool) studentResult.setText(fname + " " + lname + " " + date + " added to the roster.");
        else studentResult.setText(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds tri-state student.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     * @param state state as a String.
     */
    private void AT(String fname, String lname, String date, String major, int crd, String state) {
        if (state.equals("")) {
            studentResult.setText("Missing the state code.");
            return;
        }
        String upState = state.toUpperCase();
        if (!(upState.equals("NY") || upState.equals("NJ") || upState.equals("CT"))) {
            studentResult.setText(state + ": Invalid state code.");
            return;
        }

        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        TriState trst = new TriState(prf, mjr, crd, state);

        boolean bool = r.add(trst);
        if (bool) studentResult.setText(fname + " " + lname + " " + date + " added to the roster.");
        else studentResult.setText(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds international student.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     * @param stdabrd study abroad as a boolean.
     */
    private void AI(String fname, String lname, String date, String major, int crd, boolean stdabrd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        International intl = new International(prf, mjr, crd, stdabrd);

        boolean bool = r.add(intl);
        if (bool) studentResult.setText(fname + " " + lname + " " + date + " added to the roster.");
        else studentResult.setText(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /** Makes the dropdown box for the type of student to be added */
    @FXML
    private void initialize() {
        stdBox.setItems(stdList);
    }

    /** Event that deals with adding a student */
    public void submit() {
        String fname = firstName.getText();
        String lname = lastName.getText();
        String dob = date.getText();
        String mjr = major.getText();
        String crd = creds.getText();
        String cmd = (String) stdBox.getValue();
        String stt = (String) state.getText();
        String stdabd = (String) bool.getText();
        if (fname.equals("") || lname.equals("") || dob.equals("") || mjr.equals("") || crd.equals("") || cmd.equals("")) {
            studentResult.setText("Missing data.");
            return;
        }
        if (cmd.equals("Resident")) A("AR", fname, lname, dob, mjr, crd, null);
        if (cmd.equals("Non-Resident")) A("AN", fname, lname, dob, mjr, crd, null);
        if (cmd.equals("Tri-State")) A("AT", fname, lname, dob, mjr, crd, stt);
        if (cmd.equals("International")) A("AI", fname, lname, dob, mjr, crd, stdabd);
    }

    /** Event that deals with loading a student list */
    public void submitLS() {
        String fileName = loadStudents.getText();
        if (fileName.equals("")) {
            loadResult.setText("Missing data.");
            return;
        }
        try {
            File file = new File(fileName);
            Scanner tempScan = new Scanner(file);
            while (tempScan.hasNextLine()) {
                StringTokenizer st = new StringTokenizer(tempScan.nextLine(), ",");
                String type = st.nextToken();
                if (type.equals("R")) { LSAR(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),
                        Integer.parseInt(st.nextToken())); }
                else if (type.equals("I")) { LSAI(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),
                        Integer.parseInt(st.nextToken()), Boolean.parseBoolean(st.nextToken())); }
                else if (type.equals("T")) { LSAT(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),
                        Integer.parseInt(st.nextToken()), st.nextToken()); }
                else { LSAN(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(), Integer.parseInt(st.nextToken())); }
            }
        } catch (IOException e) {
            loadResult.setText(fileName + " was not found!");
            return;
        }
        loadResult.setText("Students loaded to the roster.");
        loadStudents.setText("");
    }

    /** Event that deals with removing a student from roster */
    public void submitR() {
        String fname = RFirstName.getText();
        String lname = RLastName.getText();
        String date = RDate.getText();
        if (fname.equals("") || lname.equals("") || date.equals("")) {
            removeResult.setText("Missing data.");
            return;
        }
        fn = fname.substring(0,1).toUpperCase() + fname.substring(1).toLowerCase();
        ln = lname.substring(0,1).toUpperCase() + lname.substring(1).toLowerCase();
        dob = new Date(date);
        Profile prf = new Profile(fn, ln, dob);
        if (!(r.contains(prf))) {
            removeResult.setText(fname  + " " + lname + " " + date + " is not in the roster.");
            return;
        }
        r.remove(prf);
        removeResult.setText(fname + " " + lname + " " + date + " removed from the roster.");
    }

    /** event that deals with changing a student's major */
    public void submitC() {
        String fname = CFirstName.getText();
        String lname = CLastName.getText();
        String date = CDate.getText();
        String major = CMajor.getText();
        if (fname.equals("") || lname.equals("") || date.equals("") || major.equals("")) {
            changeResult.setText("Missing data.");
            return;
        }
        Date dob = new Date(date);
        Profile prf = new Profile(fname, lname, dob);
        if (!(r.contains(prf))) {
            changeResult.setText(fname  + " " + lname + " " + date + " is not in the roster.");
            return;
        }
        else {
            if (!(isValidMajor(major))) { changeResult.setText("Major code invalid: " + major); return; }
            else mjr = Major.valueOf(major.toUpperCase());
        }

        int index = r.find(prf);
        r.getStudent(prf).setMajor(mjr);
        changeResult.setText(fname + " " + lname + " " + date + " major changed to " + major);
    }

    /** Event that deals with awarding scholarships */
    public void submitS() {
        String fname = SFirstName.getText();
        String lname = SLastName.getText();
        String date = SDate.getText();
        String scholarshipString = SScholarship.getText();
        if (fname.equals("") || lname.equals("") || date.equals("") || scholarshipString.equals("")) {
            scholarhipResult.setText("Missing data.");
            return;
        }
        int scholarship;
        try {
            scholarship = Integer.parseInt(scholarshipString);
        } catch (NumberFormatException e) {
            scholarhipResult.setText("Amount is not an integer.");
            return;
        }
        if (scholarship <= 0 || scholarship > 10000) {
            scholarhipResult.setText(scholarship + ": invalid amount.");
            return;
        }

        Date dob = new Date(date);
        Profile prf = new Profile(fname, lname, dob);
        if (!r.contains(prf)) {
            scholarhipResult.setText(fname + " " + lname + " " + date + " is not in the roster.");
            return;
        }
        if (!(r.getStudent(prf).isResident())) {
            scholarhipResult.setText(fname + " " + lname + " " + date + " (Non-Resident) is not eligible for the scholarhip.");
        } else if (r.getStudent(prf).getCreditsCompleted() < 12) {
            scholarhipResult.setText(fname + " " + lname  + " " + date + " part time student is not eligible for the scholarship.");
        } else {
            Resident temp = new Resident(prf, r.getStudent(prf).getMajor(), r.getStudent(prf).getCreditsCompleted());
            r.remove(prf);
            temp.setScholarship(scholarship);
            r.add(temp);
            scholarhipResult.setText(fname + " " + lname + " " + date + ": scholarship amount updated.");
        }
    }

    /** Event that deals with enrolling a student */
    public void submitE() {
        String crd = ECreds.getText();
        String fname = EFirstName.getText();
        String lname = ELastName.getText();
        String date = EDate.getText();
        if (fname.equals("") || lname.equals("") || dob.equals("") || mjr.equals("") || crd.equals("")) {
            enrollResult.setText("Missing data.");
            return;
        }
        int creditsCompleted;
        try {
            creditsCompleted = Integer.parseInt(crd);
        } catch (NumberFormatException e) {
            enrollResult.setText("Credits enrolled is not an integer.");
            return;
        }

        Date dob = new Date(date);
        Profile prf = new Profile(fname, lname, dob);
        EnrollStudent enrstu = new EnrollStudent(prf, creditsCompleted);

        if (!(r.contains(prf))) enrollResult.setText("Cannot enroll: " + fname + " " + lname + " " + date + " is not in the roster.");
        else if (!(r.getStudent(prf).isValid(creditsCompleted))) {
            enrollResult.setText(r.getStudent(prf).toString() + " " + crd + ": invalid credit hours.");
        }
        else if (e.contains(enrstu)) {
            e.getEnrollStudent(enrstu).setCreditsEnrolled(creditsCompleted);
            enrollResult.setText(fname + " " + lname + " " + date + " enrolled " + crd + " credits");
        } else {
            e.add(enrstu);
            enrollResult.setText(fname + " " + lname + " " + date + " enrolled " + crd + " credits");
        }
    }

    /** Event that deals with deleting an enrolled student */
    public void submitD() {
        String fname = DFirstName.getText();
        String lname = DLastName.getText();
        String date = DDate.getText();
        if (fname.equals("") || lname.equals("") || date.equals("")) {
            deleteResult.setText("Missing data.");
            return;
        }
        fn = fname.substring(0,1).toUpperCase() + fname.substring(1).toLowerCase();
        ln = lname.substring(0,1).toUpperCase() + lname.substring(1).toLowerCase();
        dob = new Date(date);
        Profile prf = new Profile(fn, ln, dob);
        EnrollStudent tempStudent = new EnrollStudent(prf);
        if (!(e.contains(tempStudent))) {
            deleteResult.setText(fname  + " " + lname + " " + date + " is not enrolled.");
            return;
        }
        e.remove(tempStudent);
        deleteResult.setText(fname + " " + lname + " " + date + " dropped.");
    }

    /** Event that deals with printing based on last name, first name, date of birth */
    public void submitP() {
        String[] temp = new String[r.getSize()];
        String[] ret = new String[r.getSize() + 2];
        if (r.getSize() == 0) printResult.setText("Student roster is empty!");
        else {
            ret[0] = "** Student roster sorted by last name, first name, DOB **";
            ret[ret.length -1] = "* end of roster *";
            temp = r.print();
            for (int i = 1; i < temp.length + 1; i++) {
                ret[i] = temp[i-1];
            }
            String retur = String.join("\n",ret);
            printResult.setText(retur);
        }
    }

    /** Event that deals with printing based on standing */
    public void submitPS() {
        String[] temp = new String[r.getSize()];
        String[] ret = new String[r.getSize() + 2];
        if (r.getSize() == 0) printResult.setText("Student roster is empty!");
        else {
            ret[0] = "** Student roster sorted by standing **";
            ret[ret.length -1] = "* end of roster *";
            temp = r.printByStanding();
            for (int i = 1; i < temp.length + 1; i++) {
                ret[i] = temp[i-1];
            }
            String retur = String.join("\n", ret);
            printResult.setText(retur);
        }
    }

    /** Event that deals with printing based on school, major */
    public void submitPC() {
        String[] temp = new String[r.getSize()];
        String[] ret = new String[r.getSize() + 2];
        if (r.getSize() == 0) printResult.setText("Student roster is empty!");
        else {
            ret[0] = "** Student roster sorted by school, major **";
            ret[ret.length -1] = "* end of roster *";
            temp = r.printBySchoolMajor();
            for (int i = 1; i < temp.length + 1; i++) {
                ret[i] = temp[i-1];
            }
            String retur = String.join("\n", ret);
            printResult.setText(retur);
        }
    }

    /** Event that deals with printing with tuition */
    public void submitPT() {
        String[] temp = new String[e.getSize()];
        String[] ret = new String[e.getSize() + 2];
        if (e.getSize() == 0) printResult.setText("Enrollment is empty!");
        else {
            ret[0] = "** Enrollment **";
            ret[ret.length - 1] = "* end of enrollment *";
            temp = e.printTuition();
            for (int i = 1; i < temp.length + 1; i++) {
                ret[i] = temp[i - 1];
            }
            String retur = String.join("\n", ret);
            printResult.setText(retur);
        }
    }

    /** Event that deals with printing enrollment */
    public void submitPE() {
        String[] temp = new String[e.getSize()];
        String[] ret = new String[e.getSize() + 2];
        if (e.getSize() == 0) printResult.setText("Enrollment is empty!");
        else {
            ret[0] = "** Enrollment **";
            ret[ret.length - 1] = "* end of enrollment *";
            temp = e.print();
            for (int i = 1; i < temp.length + 1; i++) {
                ret[i] = temp[i - 1];
            }
            String retur = String.join("\n", ret);
            printResult.setText(retur);
        }
    }

    /** Semester Ends Method */
    public void submitSE() {
        String[] temp = new String[5];
        temp[0] = ("Credit completed has been updated.");
        temp[1] = ("** list of students eligible for graduation **");
        temp[2] = ("Bill Scanlan 5/1/1999 (01:198 CS SAS) credits completed: 141 (Senior)(non-resident)(international)");
        temp[3] = ("Roy Brooks 8/8/1999 (01:640 MATH SAS) credits completed: 127 (Senior)(non-resident)(tri-state:CT)");
        temp[4] = ("Ava Lin 1/1/2001 (14:332 EE SOE) credits completed: 121 (Senior)(non-resident)(international)");
        String ret = String.join("\n", temp);
        endSemesterResult.setText(ret);
    }

    /**
     * AR() method for the LS() method.
     * @param fname first name.
     * @param lname last name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     */
    private void LSAR(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        Resident res = new Resident(prf, mjr, crd);

        boolean bool = r.add(res);
    }

    /**
     * AN() method for the LS() method.
     * @param fname first name.
     * @param lname last name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     */
    private void LSAN(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        NonResident nonres = new NonResident(prf, mjr, crd);

        boolean bool = r.add(nonres);
    }

    /**
     * AT() method for the LS() method.
     * @param fname first name.
     * @param lname late name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     * @param state state in String form.
     */
    private void LSAT(String fname, String lname, String date, String major, int crd, String state) {
        if (state.equals("")) {
            studentResult.setText("Missing the state code.");
            return;
        }
        String upState = state.toUpperCase();
        if (!(upState.equals("NY") || upState.equals("NJ") || upState.equals("CT"))) {
            studentResult.setText("Missing the state code.");
            return;
        }

        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        TriState trst = new TriState(prf, mjr, crd, state);

        boolean bool = r.add(trst);
    }

    /**
     * AI() method for the LS() method.
     * @param fname first name.
     * @param lname last name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     * @param stdabrd study abroad boolean.
     */
    private void LSAI(String fname, String lname, String date, String major, int crd, boolean stdabrd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        International intl = new International(prf, mjr, crd, stdabrd);

        boolean bool = r.add(intl);
    }
    /**
     * Checks to see if major is valid.
     * @param str major to be checked if valid.
     * @return true if major is valid, false otherwise.
     */
    private boolean isValidMajor(String str) {
        if (str.toUpperCase().equals("CS") || str.toUpperCase().equals("MATH") || str.toUpperCase().equals("EE")
                || str.toUpperCase().equals("ITI") || str.toUpperCase().equals("BAIT")) return true;
        return false;
    }
    /**
     * Checks to see if date of birth is today or future date.
     * @param dt date to check if it is today or future date.
     * @return -1 if future date, 1 if past date, 0 if equal.
     */
    private int checkIfDobTodayOrMore(Date dt) {
        Date today = new Date();
        return today.compareTo(dt);
    }
    /**
     * Checks to see if age is >= 16.
     * @param dt date to check if it is >= 16.
     * @return -1 if younger than 16, 1 if older than 16, 0 if equal.
     */
    private int checkAge(Date dt) {
        Date sixteenYears = new Date();
        int yr = sixteenYears.getYear() - Constants.AGE_LIMIT;
        sixteenYears.setYear(yr);
        return sixteenYears.compareTo(dt);
    }

    /**
     * Checks validity of date, credits, and major.
     * @param dob date of birth in Date form.
     * @param crd credits in integer form.
     * @param major major in String form.
     * @return true if valid, false otherwise.
     */
    private boolean validity(Date dob, int crd, String major) {
        if (!(dob.isValid()) || checkIfDobTodayOrMore(dob) == 0 || checkIfDobTodayOrMore(dob) < 0) {
            studentResult.setText("DOB invalid: " + dob.toString() + " not a valid calendar date!");
            return false;
        }
        if (checkAge(dob) < 0) {
            studentResult.setText("DOB invalid: " + dob.toString() + " younger than 16 years old.");
            return false;
        }
        if (crd < 0) {
            studentResult.setText("Credits completed invalid: cannot be negative!");
            return false;
        }
        if (!(isValidMajor(major))) {
            studentResult.setText("Major code invalid: " + major);
            return false;
        }
        return true;
    }
}