package com.example.project_three;
/**
 * EnrollStudent object which is used in Enrollment
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class EnrollStudent {
    /** profile as a Profile object */
    private Profile profile;
    /** credits enrolled as an integer */
    private int creditsEnrolled;

    /**
     * Constructor for EnrollStudent with profile and credits enrolled as parameters.
     * @param prof profile as a Profile object.
     * @param creds credits enrolled as an integer.
     */
    public EnrollStudent(Profile prof, int creds) {
        this.profile = prof;
        this.creditsEnrolled = creds;
    }

    /**
     * Constructor for EnrollStudent with profile as a parameter which sets credits enrolled to 0.
     * @param prof profile as a Profile object.
     */
    public EnrollStudent(Profile prof) {
        this.profile = prof;
        this.creditsEnrolled = 0;
    }

    /**
     * Gets the EnrollStudent profile.
     * @return EnrollStudent profile
     */
    public Profile getESProfile() {
        return profile;
    }

    /**
     * Gets credits enrolled.
     * @return credits enrolled as an integer.
     */
    public int getCreditsEnrolled() {
        return creditsEnrolled;
    }

    /**
     * Sets the credits enrolled to a specified amount.
     * @param newcreds credits to set creditsEnrolled to.
     */
    public void setCreditsEnrolled(int newcreds) { this.creditsEnrolled = newcreds; }

    /**
     * Overrides equals(Object obj) to fit EnrollStudent.
     * @param obj to see if this object is equal to or not.
     * @return true if equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj){
        if (obj == this) return true;
        if (!(obj instanceof EnrollStudent)) return false;
        EnrollStudent s = (EnrollStudent) obj;
        return s.getESProfile().equals(this.profile) && (s.getCreditsEnrolled() == this.creditsEnrolled);
    }

    /**
     * Overrides toString() method.
     * @return "[FIRST_NAME] [LAST_NAME] [DOB] [CLASS] [CREDITS ENROLLED]"
     */
    @Override // update later
    public String toString(){
        return this.profile.getFname() + " " + this.profile.getLname() + " " + this.profile.getDob() + " "
                + this.profile.getClass() + " " + this.creditsEnrolled;
    }

    /**
     * Compares to EnrollStudent objects.
     * @param enrollstudent EnrollStudent student to compare to.
     * @return 0 if equal, -1 if this object is before enrollstudent, 1 otherwise.
     */
    public int compareTo(EnrollStudent enrollstudent) {
        if (!this.profile.equals(enrollstudent.getESProfile())) { return this.profile.compareTo(enrollstudent.getESProfile());}
        return 0;
    }
}