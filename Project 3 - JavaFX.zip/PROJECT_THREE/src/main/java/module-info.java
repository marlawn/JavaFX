module com.example.project_three {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.project_three to javafx.fxml;
    exports com.example.project_three;
}